import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { KartsApiService } from '../../../api-services/karts/karts-api.service';
import { ListKartsQueryDto } from '../../../api-services/karts/karts-api.models';

type SortKey = 'name' | 'price';
type SortDir = 'asc' | 'desc';

// Ako NEMAŠ kubikažu u DTO, koristi powertrain filtere:
type QuickFilter =
  | { kind: 'all' }
  | { kind: 'powertrain'; id: number }        // npr 1=2T, 2=4T, 3=Electric
  | { kind: 'enabled'; only: boolean };

@Component({
  selector: 'app-karts',
  standalone: false,
  template: `
    <section class="karts-page">
      <div class="container wrap">
        <div class="side"><div class="vertical">PONUDA KARTOVA</div></div>

        <div class="panel">
          <!-- TOP BAR -->
          <div class="topbar">
            <form class="search" (submit)="onSearch($event)">
              <span class="sicon" aria-hidden="true">⌕</span>
              <input
                type="text"
                [(ngModel)]="q"
                name="q"
                placeholder="Pretraži kartove (naziv, proizvođač, boja)..."
                aria-label="Pretraži kartove"
              />
              <button class="sbtn" type="submit">Traži</button>
            </form>

            <div class="actions">
              <button class="btn ghost" type="button" (click)="reset()">Reset</button>
            </div>
          </div>

          <!-- QUICK FILTERS -->
          <div class="filters">
            <button
              class="pill"
              [class.active]="filter.kind === 'all'"
              (click)="setFilter({ kind: 'all' })"
              type="button"
            >
              Sve
            </button>

            <button
              class="pill"
              [class.active]="filter.kind === 'enabled' && filter.only"
              (click)="setFilter({ kind: 'enabled', only: true })"
              type="button"
            >
              Samo aktivni
            </button>

            <!-- Powertrain quick filters (zamijeni nazive po tvom sistemu) -->
            <button
              class="pill"
              [class.active]="filter.kind === 'powertrain' && filter.id === 1"
              (click)="setFilter({ kind: 'powertrain', id: 1 })"
              type="button"
            >
              2T
            </button>

            <button
              class="pill"
              [class.active]="filter.kind === 'powertrain' && filter.id === 2"
              (click)="setFilter({ kind: 'powertrain', id: 2 })"
              type="button"
            >
              4T
            </button>

            <button
              class="pill"
              [class.active]="filter.kind === 'powertrain' && filter.id === 3"
              (click)="setFilter({ kind: 'powertrain', id: 3 })"
              type="button"
            >
              Električni
            </button>

            <div class="spacer"></div>

            <!-- SORT -->
            <div class="sortbox">
              <label class="lbl">Sort:</label>

              <button
                class="pill ghost"
                [class.active]="sortKey === 'name'"
                type="button"
                (click)="setSort('name')"
              >
                Naziv
              </button>

              <button
                class="pill ghost"
                [class.active]="sortKey === 'price'"
                type="button"
                (click)="setSort('price')"
              >
                Cijena
              </button>

              <button class="pill ghost" type="button" (click)="toggleDir()">
                {{ sortDir === 'asc' ? 'ASC ↑' : 'DESC ↓' }}
              </button>
            </div>
          </div>

          <!-- GRID -->
          <div class="grid" *ngIf="!loading; else loadingTpl">
            <div class="empty" *ngIf="viewKarts.length === 0">
              Nema kartova za prikaz.
            </div>

            <div class="card" *ngFor="let k of viewKarts" (click)="openDetails(k.id)">
              <div class="img-wrap">
                <img class="img" [src]="k.imageUrl || 'https://placehold.co/600x400'" alt="Kart image" />
              </div>

              <div class="body">
                <div class="title">{{ k.name }}</div>

                <div class="meta">
                  <span>{{ k.manufacturer || '—' }}</span>
                  <span class="dot">•</span>
                  <span>{{ k.colour || '—' }}</span>
                </div>

                <div class="price" *ngIf="k.pricePerSession != null">
                  {{ k.pricePerSession }} KM / vožnja
                </div>

                <div class="desc" *ngIf="k.description">
                  {{ k.description }}
                </div>

                <div class="cta">
                  <span class="link">Detalji</span>
                </div>
              </div>
            </div>
          </div>

          <ng-template #loadingTpl>
            <div class="loading">Učitavanje...</div>
          </ng-template>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .karts-page{ min-height:calc(100vh - 74px); background:#000; color:#fff; padding:26px 0 46px; }
    .wrap{ display:flex; gap:26px; align-items:stretch; }
    .side{ width:84px; display:flex; align-items:center; justify-content:center; }
    .vertical{ writing-mode:vertical-rl; transform:rotate(180deg); font-weight:900; letter-spacing:6px; font-size:54px; color:rgba(255,255,255,.85); text-transform:uppercase; }
    .panel{ flex:1; background:#4a4a4a; border-radius:10px; padding:18px 18px 20px; box-shadow:0 0 50px rgba(0,0,0,.45); }

    .topbar{ display:flex; gap:14px; align-items:center; justify-content:space-between; padding:4px 4px 12px; }
    .search{
      flex:1;
      display:flex;
      align-items:center;
      gap:10px;
      background:rgba(255,255,255,.95);
      border-radius:999px;
      padding:8px 10px 8px 12px;
      box-shadow: inset 0 0 0 2px rgba(0,0,0,.08);
    }
    .sicon{ font-weight:900; color:rgba(0,0,0,.6); }
    .search input{ border:none; outline:none; width:100%; background:transparent; font-weight:700; }
    .sbtn{
      border:none; cursor:pointer;
      border-radius:999px; padding:10px 14px;
      font-weight:900;
      background:#111; color:#fff;
    }
    .actions{ display:flex; gap:10px; }
    .btn{ border:none; cursor:pointer; border-radius:12px; padding:10px 14px; font-weight:900; background:#111; color:#fff; }
    .btn.ghost{ background:transparent; outline:1px solid rgba(255,255,255,.25); color:rgba(255,255,255,.95); }

    .filters{
      display:flex; flex-wrap:wrap; gap:10px;
      align-items:center;
      padding:0 4px 14px;
    }
    .spacer{ flex:1; }
    .sortbox{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; justify-content:flex-end; }
    .lbl{ font-weight:900; opacity:.85; }

    .pill{
      border:none; cursor:pointer;
      border-radius:999px; padding:10px 14px;
      font-weight:900;
      background:rgba(0,0,0,.35);
      color:rgba(255,255,255,.92);
    }
    .pill.active{ background:#fff; color:#000; }
    .pill.ghost{ background:transparent; outline:1px solid rgba(255,255,255,.25); }

    .grid{ display:grid; grid-template-columns:repeat(3, minmax(0, 1fr)); gap:14px; }
    @media (max-width:1100px){ .grid{ grid-template-columns:repeat(2, minmax(0, 1fr)); } }
    @media (max-width:720px){
      .wrap{ flex-direction:column; }
      .side{ width:auto; }
      .vertical{ writing-mode:initial; transform:none; font-size:28px; letter-spacing:3px; }
      .grid{ grid-template-columns:1fr; }
      .topbar{ flex-direction:column; align-items:stretch; }
      .actions{ justify-content:flex-end; }
    }

    .card{
      border-radius:12px;
      overflow:hidden;
      background:rgba(0,0,0,.45);
      border:1px solid rgba(255,255,255,.15);
      cursor:pointer;
      transition: transform .12s ease, border-color .12s ease;
    }
    .card:hover{ transform: translateY(-2px); border-color: rgba(255,255,255,.28); }

    .img{ width:100%; height:160px; object-fit:cover; display:block; background:rgba(255,255,255,.06); }
    .body{ padding:12px; }
    .title{ font-weight:900; letter-spacing:.2px; }
    .meta{ margin-top:6px; display:flex; gap:8px; font-weight:800; color:rgba(255,255,255,.82); font-size:13px; }
    .dot{ opacity:.6; }
    .price{ margin-top:10px; font-weight:900; }
    .desc{ margin-top:8px; opacity:.9; font-weight:700; font-size:13px; line-height:1.35; }
    .cta{ margin-top:12px; }
    .link{ font-weight:900; text-decoration:underline; }
    .loading{ padding:26px 6px; font-weight:900; opacity:.9; }
    .empty{ grid-column:1/-1; text-align:center; padding:30px 10px; font-weight:900; opacity:.9; }
  `],
})
export class KartComponent implements OnInit {
  karts: ListKartsQueryDto[] = [];
  viewKarts: ListKartsQueryDto[] = [];
  loading = false;

  q = '';
  onlyEnabled = true;

  // quick filter + sort (frontend)
  filter: QuickFilter = { kind: 'enabled', only: true };
  sortKey: SortKey = 'name';
  sortDir: SortDir = 'asc';

  constructor(private kartsApi: KartsApiService, private router: Router) {}

  ngOnInit(): void {
    this.loadKarts();
  }

  onSearch(e: Event): void {
    e.preventDefault();
    this.loadKarts();
  }

  setFilter(f: QuickFilter): void {
    this.filter = f;
    // ako filter traži "samo aktivni", ažuriraj onlyEnabled i refetch
    if (f.kind === 'enabled') {
      this.onlyEnabled = f.only;
      this.loadKarts();
      return;
    }
    // ostalo može i local nakon fetch
    this.applyLocal();
  }

  setSort(key: SortKey): void {
    this.sortKey = key;
    this.applyLocal();
  }

  toggleDir(): void {
    this.sortDir = this.sortDir === 'asc' ? 'desc' : 'asc';
    this.applyLocal();
  }

  reset(): void {
    this.q = '';
    this.onlyEnabled = true;
    this.filter = { kind: 'enabled', only: true };
    this.sortKey = 'name';
    this.sortDir = 'asc';
    this.loadKarts();
  }

  loadKarts(): void {
    this.loading = true;
    this.kartsApi
      .list({
        search: this.q?.trim() || undefined,
        onlyEnabled: this.onlyEnabled,
        paging: { page: 1, pageSize: 60 },
      })
      .subscribe({
        next: (res) => {
          this.karts = res.items || [];
          this.applyLocal();
        },
        error: (err) => {
          console.error('Karts list error:', err);
          this.karts = [];
          this.viewKarts = [];
        },
        complete: () => (this.loading = false),
      });
  }

  private applyLocal(): void {
    let items = [...(this.karts || [])];

    // quick filter (powertrain)
    if (this.filter.kind === 'powertrain') {
      // @ts-ignore - ako ti DTO nema powertrainTypeId, dodaj ga u model ili skloni ovaj filter
      items = items.filter((x: any) => x.powertrainTypeId === this.filter.id);
    }

    // sort
    const dir = this.sortDir === 'asc' ? 1 : -1;
    items.sort((a: any, b: any) => {
      if (this.sortKey === 'price') {
        const ap = a.pricePerSession ?? -1;
        const bp = b.pricePerSession ?? -1;
        return (ap - bp) * dir;
      }
      // name default
      const an = (a.name || '').toString().toLowerCase();
      const bn = (b.name || '').toString().toLowerCase();
      return an.localeCompare(bn) * dir;
    });

    this.viewKarts = items;
  }

  openDetails(id: number): void {
    this.router.navigate(['/karts', id]);
  }
}
