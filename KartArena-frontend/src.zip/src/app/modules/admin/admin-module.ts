import { NgModule } from '@angular/core';

import { AdminRoutingModule } from './admin-routing-module';
import { SharedModule } from '../shared/shared-module';

import { AdminLayoutComponent } from './admin-layout/admin-layout.component';
import { AdminSettingsComponent } from './admin-settings/admin-settings.component';

import { EquipmentComponent } from './equipment/equipment.component';
import { EquipmentAddComponent } from './equipment/equipment-add/equipment-add.component';
import { EquipmentEditComponent } from './equipment/equipment-edit/equipment-edit.component';
import { ConfirmDeleteDialogComponent } from './equipment/dialogs/confirm-delete/confirm-delete-dialog.component';

import { ReservationComponent } from './reservation/reservation.component';
import { ReservationAddComponent } from './reservation/reservation-add/reservation-add.component';
import { ReservationEditComponent } from './reservation/reservation-edit/reservation-edit.component';
import { ConfirmDeleteDialogReservationComponent } from './reservation/dialogs/confirm-delete/confirm-delete-dialog.component';


import { KartsComponent } from './karts/karts.component';
import { KartsAddComponent } from './karts/karts-add/karts-add.component';
import { KartsEditComponent } from './karts/karts-edit/karts-edit.component';
import { ConfirmDeleteDialogComponent as ConfirmDeleteKartDialogComponent } from './karts/dialogs/confirm-delete/confirm-delete-dialog.component';


@NgModule({
  declarations: [
    AdminLayoutComponent,
    AdminSettingsComponent,
    EquipmentComponent,
    EquipmentAddComponent,
    EquipmentEditComponent,
    ConfirmDeleteDialogComponent,
    ReservationComponent,
    ReservationAddComponent,
    ReservationEditComponent,
    ConfirmDeleteDialogReservationComponent,
     KartsComponent,
    KartsAddComponent,
    KartsEditComponent,
    ConfirmDeleteKartDialogComponent,
  ],
  imports: [
    AdminRoutingModule,
    SharedModule,
  ],
})
export class AdminModule {}
