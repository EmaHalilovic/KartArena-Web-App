import { Injectable, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GetEquipmentByIdQueryDto } from '../../../../api-services/equipment/equipment-api.models';

@Injectable()
export class EquipmentFormService {
  private fb = inject(FormBuilder);

  createEquipmentForm(equipment?: GetEquipmentByIdQueryDto): FormGroup {
    return this.fb.group({
      name: [
        equipment?.name ?? '',
        [Validators.required, Validators.minLength(2), Validators.maxLength(100)],
      ],
      description: [equipment?.description ?? '', [Validators.maxLength(500)]],
      price: [
        equipment?.price ?? 0,
        [Validators.required, Validators.min(0.01), Validators.max(1000000)],
      ],
      quantity: [
        equipment?.quantity ?? 0,
        [Validators.required, Validators.min(0), Validators.max(1000000)],
      ],
      size: [
        equipment?.size ?? '',
        [Validators.required, Validators.minLength(1), Validators.maxLength(50)],
      ],
    });
  }

  getErrorMessage(form: FormGroup, controlName: string): string {
    const control = form.get(controlName);
    if (!control || !control.errors || !control.touched) {
      return '';
    }

    const errors = control.errors;

    if (errors['required']) return 'This field is required';
    if (errors['minlength']) return `Minimum ${errors['minlength'].requiredLength} characters required`;
    if (errors['maxlength']) return `Maximum ${errors['maxlength'].requiredLength} characters allowed`;
    if (errors['min']) return `Minimum value is ${errors['min'].min}`;
    if (errors['max']) return `Maximum value is ${errors['max'].max}`;

    return 'Invalid value';
  }
}
