import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { BaseFormComponent } from '../../../../core/components/base-classes/base-form-component';
import {
  GetEquipmentByIdQueryDto,
  UpdateEquipmentCommand,
} from '../../../../api-services/equipment/equipment-api.models';
import { EquipmentApiService } from '../../../../api-services/equipment/equipment-api.service';
import { ToasterService } from '../../../../core/services/toaster.service';
import { EquipmentFormService } from '../services/equipment-form.service';

@Component({
  selector: 'app-equipment-edit',
  standalone: false,
  templateUrl: './equipment-edit.component.html',
  styleUrl: './equipment-edit.component.scss',
  providers: [EquipmentFormService],
})
export class EquipmentEditComponent
  extends BaseFormComponent<GetEquipmentByIdQueryDto>
  implements OnInit
{
  private api = inject(EquipmentApiService);
  private formService = inject(EquipmentFormService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private toaster = inject(ToasterService);

  equipmentId!: number;

  ngOnInit(): void {
    this.equipmentId = +this.route.snapshot.params['id'];
    this.initForm(true);
  }

  protected loadData(): void {
    this.startLoading();

    this.api.getById(this.equipmentId).subscribe({
      next: (equipment) => {
        this.model = equipment;
        this.form = this.formService.createEquipmentForm(equipment);
        this.stopLoading();
      },
      error: (err) => {
        this.stopLoading('Failed to load equipment');
        this.toaster.error('Equipment not found');
        console.error('Load equipment error:', err);
        this.router.navigate(['/admin/equipment']);
      },
    });
  }

  protected save(): void {
    if (this.form.invalid || this.isLoading) {
      return;
    }

    this.startLoading();

    const payload: UpdateEquipmentCommand = this.form.getRawValue();

    this.api.update(this.equipmentId, payload).subscribe({
      next: () => {
        this.stopLoading();
        this.toaster.success('Equipment updated successfully');
        this.router.navigate(['/admin/equipment']);
      },
      error: (err) => {
        this.stopLoading('Failed to update equipment');
        console.error('Update equipment error:', err);
      },
    });
  }

  onCancel(): void {
    this.router.navigate(['/admin/equipment']);
  }

  getErrorMessage(controlName: string): string {
    return this.formService.getErrorMessage(this.form, controlName);
  }
}
