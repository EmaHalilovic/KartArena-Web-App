import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import {
  ListEquipmentRequest,
  ListEquipmentQueryDto,
} from '../../../api-services/equipment/equipment-api.models';
import { EquipmentApiService } from '../../../api-services/equipment/equipment-api.service';
import { BaseListPagedComponent } from '../../../core/components/base-classes/base-list-paged-component';
import { ToasterService } from '../../../core/services/toaster.service';
import { ConfirmDeleteDialogComponent } from './dialogs/confirm-delete/confirm-delete-dialog.component';

@Component({
  selector: 'app-equipment',
  standalone: false,
  templateUrl: './equipment.component.html',
  styleUrl: './equipment.component.scss',
})
export class EquipmentComponent
  extends BaseListPagedComponent<ListEquipmentQueryDto, ListEquipmentRequest>
  implements OnInit
{
  private api = inject(EquipmentApiService);
  private router = inject(Router);
  private dialog = inject(MatDialog);
  private toaster = inject(ToasterService);

  displayedColumns: string[] = [
    'name',
    'price',
    'quantity',
    'size',
    'status',
    'actions',
  ];

  showOnlyEnabled = false;

  constructor() {
    super();
    this.request = new ListEquipmentRequest();
  }

  ngOnInit(): void {
    this.initList();
  }

  protected loadPagedData(): void {
    this.startLoading();

    this.api.list(this.request).subscribe({
      next: (response) => {
        this.handlePageResult(response);
        this.stopLoading();
      },
      error: (err) => {
        this.stopLoading('Failed to load equipment');
        console.error('Load equipment error:', err);
      },
    });
  }

  // === UI Actions ===

  onCreate(): void {
    this.router.navigate(['/admin/equipment/add']);
  }

  onEdit(item: ListEquipmentQueryDto): void {
    this.router.navigate(['/admin/equipment', item.id, 'edit']);
  }

  onDelete(item: ListEquipmentQueryDto): void {
    const ref = this.dialog.open(ConfirmDeleteDialogComponent, {
      width: '420px',
      maxWidth: '95vw',
      data: {
        titleKey: 'EQUIPMENT.DIALOGS.DELETE_TITLE',
        messageKey: 'EQUIPMENT.DIALOGS.DELETE_MESSAGE',
        name: item.name,
        confirmKey: 'EQUIPMENT.DIALOGS.DELETE_CONFIRM',
        cancelKey: 'EQUIPMENT.DIALOGS.DELETE_CANCEL',
      },
    });

    ref.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.performDelete(item);
      }
    });
  }

  private performDelete(item: ListEquipmentQueryDto): void {
    this.startLoading();

    this.api.delete(item.id).subscribe({
      next: () => {
        this.toaster.success('Equipment deleted successfully');
        this.loadPagedData();
      },
      error: (err) => {
        this.stopLoading('Failed to delete equipment');
        console.error('Delete equipment error:', err);
      },
    });
  }

  onToggleStatus(item: ListEquipmentQueryDto): void {
    this.startLoading();

    const call$ = item.status ? this.api.disable(item.id) : this.api.enable(item.id);

    call$.subscribe({
      next: () => {
        this.toaster.success(`Equipment ${item.status ? 'disabled' : 'enabled'} successfully`);
        this.loadPagedData();
      },
      error: (err) => {
        this.stopLoading('Failed to change equipment status');
        console.error('Toggle equipment status error:', err);
      },
    });
  }

  onSearch(): void {
    this.request.paging.page = 1;
    this.loadPagedData();
  }

  onToggleEnabledFilter(checked: boolean): void {
    this.showOnlyEnabled = checked;
    this.request.onlyEnabled = checked;
    this.request.paging.page = 1;
    this.loadPagedData();
  }
}
