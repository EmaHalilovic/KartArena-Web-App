import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { BaseFormComponent } from '../../../../core/components/base-classes/base-form-component';
import {
  CreateEquipmentCommand,
  GetEquipmentByIdQueryDto,
} from '../../../../api-services/equipment/equipment-api.models';
import { EquipmentApiService } from '../../../../api-services/equipment/equipment-api.service';
import { ToasterService } from '../../../../core/services/toaster.service';
import { EquipmentFormService } from '../services/equipment-form.service';

@Component({
  selector: 'app-equipment-add',
  standalone: false,
  templateUrl: './equipment-add.component.html',
  styleUrl: './equipment-add.component.scss',
  providers: [EquipmentFormService],
})
export class EquipmentAddComponent
  extends BaseFormComponent<GetEquipmentByIdQueryDto>
  implements OnInit
{
  private api = inject(EquipmentApiService);
  private formService = inject(EquipmentFormService);
  private router = inject(Router);
  private toaster = inject(ToasterService);

  ngOnInit(): void {
    this.initForm(false);
  }

  protected loadData(): void {
    // Add mode: no data to load
  }

  protected override initForm(isEdit: boolean): void {
    super.initForm(isEdit);
    this.form = this.formService.createEquipmentForm();
  }

  protected save(): void {
    if (this.form.invalid || this.isLoading) {
      return;
    }

    this.startLoading();

    const command: CreateEquipmentCommand = {
      name: this.form.value.name,
      price: this.form.value.price,
      quantity: this.form.value.quantity,
      size: this.form.value.size,
      description: this.form.value.description,
    };

    this.api.create(command).subscribe({
      next: () => {
        this.stopLoading();
        this.toaster.success('Equipment created successfully');
        this.router.navigate(['/admin/equipment']);
      },
      error: (err) => {
        this.stopLoading('Failed to create equipment');
        console.error('Create equipment error:', err);
      },
    });
  }

  onCancel(): void {
    this.router.navigate(['/admin/equipment']);
  }

  getErrorMessage(controlName: string): string {
    return this.formService.getErrorMessage(this.form, controlName);
  }
}
