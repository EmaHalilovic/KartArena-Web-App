import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ListEquipmentRequest,
  ListEquipmentResponse,
  GetEquipmentByIdQueryDto,
  CreateEquipmentCommand,
  UpdateEquipmentCommand,
} from './equipment-api.models';
import { buildHttpParams } from '../../core/models/build-http-params';

@Injectable({ providedIn: 'root' })
export class EquipmentApiService {
  /**
   * NOTE: Backend controller uses: [Route("equipment/controller")]
   */
  private readonly baseUrl = `${environment.apiUrl}/equipment/controller`;
  private http = inject(HttpClient);

  list(request?: ListEquipmentRequest): Observable<ListEquipmentResponse> {
    const params = request ? buildHttpParams(request as any) : undefined;
    return this.http.get<ListEquipmentResponse>(this.baseUrl, { params });
  }

  getById(id: number): Observable<GetEquipmentByIdQueryDto> {
    return this.http.get<GetEquipmentByIdQueryDto>(`${this.baseUrl}/${id}`);
  }

  /**
   * Controller returns: Created("", new { id })
   * If your API returns { id: number }, change the return type to Observable<{id:number}>.
   */
  create(payload: CreateEquipmentCommand): Observable<any> {
    return this.http.post<any>(this.baseUrl, payload);
  }

  update(id: number, payload: UpdateEquipmentCommand): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}`, payload);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  enable(id: number): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}/enable`, {});
  }

  disable(id: number): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}/disable`, {});
  }
}
