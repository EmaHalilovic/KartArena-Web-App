import { PageResult } from '../../core/models/paging/page-result';
import { BasePagedQuery } from '../../core/models/paging/base-paged-query';

export class ListEquipmentRequest extends BasePagedQuery {
  search?: string | null;
  onlyEnabled?: boolean | null;
}

export interface ListEquipmentQueryDto {
  id: number;
  name: string;
  price: number;
  quantity: number;
  size: string;
  description: string;
  status: boolean;
}

export type ListEquipmentResponse = PageResult<ListEquipmentQueryDto>;

export interface GetEquipmentByIdQueryDto {
  id: number;
  name: string;
  price: number;
  quantity: number;
  size: string;
  description: string;
  status: boolean;
}

export interface CreateEquipmentCommand {
  name: string;
  price: number;
  quantity: number;
  size: string;
  description?: string | null;
}

export interface UpdateEquipmentCommand {
  name?: string | null;
  price?: number | null;
  quantity?: number | null;
  size?: string | null;
  description?: string | null;
}
